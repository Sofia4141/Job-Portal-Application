import React from 'react'

const UserDashboard = () => {
    return (
        <>
            <h1>user Dashboard</h1>
        </>
    )
}

export default UserDashboard