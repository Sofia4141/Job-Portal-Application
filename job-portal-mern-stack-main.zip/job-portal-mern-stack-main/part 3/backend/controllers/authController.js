

exports.signin = (req, res) => {
    res.send("Hello from Node Js");
}
